@echo off
cd /d "%~dp0"
call npm install
if not exist out mkdir out
call npx remotion render src/index.jsx Full out\test.mp4 --gl=angle --frames=0-29 --image-format=jpeg --jpeg-quality=92
echo.
echo Done: out\test.mp4 (30 frames)
pause
