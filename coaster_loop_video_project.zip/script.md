# रोलर कोस्टर का लूप - script (63.9 s, Hindi, your voice-over)

## Shot table
See camera_plan.md and sentence_times.json (S1-S23, 10 shots).

## Rulebook check
- First word at t=0, premise in first sentence: yes. Hook = S1+S2, 13 words (limit 5-23), ends 6.4 s (a little above the 4-5 s aim; your voice-over pace).
- One idea per sentence, simple words: yes. Pivot "पर सुनिए" at 58%: inside 53-87%.
- Ending: stops on the arrival of the rival's trolley at the bottom of the round loop (your last line), no extra shot.

## Fact map
- Loops with a circular shape put very large force on riders at the bottom; modern teardrop-shaped (clothoid) loops fix this. Sources: Coasters-101 "Vertical Loops", Wikipedia "Vertical loop".
- Early circular loops: Flip Flap Railway (1895, Coney Island) and Paris Centrifugal Railway (1848). Sources: Coaster101, Wikipedia "Roller coaster inversion".

## Left out on purpose / NOT verified
- The story itself (hammer, rival's night sabotage, owner riding first) has no source I could find. The video treats it as a tale: nothing on screen says "true story".
- "दुनिया की पहली उल्टी राइड" (S3) is in your audio but is not accurate as stated (inversions date from 1848; first US loop 1895; first modern loop 1976). I put no on-screen claim about it. Consider re-recording as "पहली उल्टी राइडों में से एक".
- The speeds "पाँच" and "साठ" (S17) are unsourced; the video shows no numbers for them.

## Wording to watch
- "पहली" in S3 and S11 ("पहली ट्रॉली") - the second is fine, the first is the factual issue above.
