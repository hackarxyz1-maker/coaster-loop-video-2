# Camera plan (beat-synced; camera keys sit on sentence times, monotone cubic ease in/out, zero speed at first and last key)

| Shot | Time | Place | Camera path (start -> end) | Foreground / mid / background | In-world labels |
|---|---|---|---|---|---|
| 1 hook | 0-6.5 | Night test yard | wide on loop + owner -> push to owner's face and hammer (distance 8.4 -> 2.2 m) | fence posts (blurred) / owner + round loop / brick warehouse, lit windows | "टेस्ट ट्रैक" |
| 2 | 6.5-13.0 | Workshop | desk with blueprint -> slide right along desk -> window where the rival peeks | chair (blurred) / desk, two models / wall, window | "ब्लूप्रिंट", "असली", "नकल" |
| 3 | 13.0-17.4 | Night yard | low push on dummy + cart -> turn to owner | rail / dummy, crushed can / warehouse | "कल ओपनिंग" |
| 4 | 17.4-24.1 | Night yard | close on owner + hammer -> pull back and rise | fence / owner, loop bottom / warehouse | - |
| 5 | 24.3-28.85 | Night yard | crane up and back as the rival presses the loop tall | fence / rival + loop / moon | "टेस्ट ट्रैक" |
| 6 | 28.85-37.1 | Park, morning | queue close -> pan past banner to owner's thin loop -> station | queue / rival loop / ferris wheel, hills | "परफेक्ट लूप", "ग्रैंड ओपनिंग", "उल्टी राइड" |
| 7 | 37.1-49.0 | Park, diorama | settle on table: hairpin road vs loop, red ring on the bottom bend | table edge / models / owner behind | "हेयरपिन", "लूप" |
| 8 | 49.24-55.9 | Park | sweep to owner's loop -> crane up it, green ring at bottom, amber ring at top | rails / trolley / ferris wheel | - |
| 9 | 56.2-58.6 | Park exit | arc down to exit platform, owner steps out and cheers | rails / owner / hills | - |
| 10 | 58.6-63.9 | Park, rival loop | low push along rival queue to the bottom of the round loop, red ring | queue / enemy trolley / ferris wheel | - |

Cuts (dip to cream 0.4 s): 6.5, 13.0, 28.85, 58.6. Pivot "पर सुनिए" at 37.1 s = 58% of the video.
