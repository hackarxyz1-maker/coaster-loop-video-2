import React from 'react';
import * as THREE from 'three';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import { INK, cachedGeo, flat } from './kit';
import { camAt, clamp } from './plan';

/* ---------- flat shape builders ---------- */
const blobG = (rx, ry, seed, amp = 0.035, n = 30) => cachedGeo(`blob${rx}_${ry}_${seed}_${amp}`, () => {
  const s = new THREE.Shape();
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const k = 1 + amp * (Math.sin(a * 3 + seed * 5.1) + 0.6 * Math.sin(a * 7 + seed * 2.3));
    const px = Math.cos(a) * rx * k, py = Math.sin(a) * ry * k;
    i ? s.lineTo(px, py) : s.moveTo(px, py);
  }
  s.closePath();
  return new THREE.ShapeGeometry(s, 6);
});
const polyG = (key, pts) => cachedGeo(key, () => {
  const s = new THREE.Shape();
  pts.forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)));
  s.closePath();
  return new THREE.ShapeGeometry(s);
});
const domeG = (rx, ry) => polyG(`dome${rx}_${ry}`, Array.from({ length: 17 }, (_, i) => { const a = (i / 16) * Math.PI; return [Math.cos(a) * rx, Math.sin(a) * ry]; }));
const ringG = (r0, r1, a0, a1) => cachedGeo(`ring${r0}_${r1}_${a0}_${a1}`, () => new THREE.RingGeometry(r0, r1, 20, 1, a0, a1));
const rectG = (w, h, x = 0, y = 0) => polyG(`rect${w}_${h}_${x}_${y}`, [[x - w / 2, y - h / 2], [x + w / 2, y - h / 2], [x + w / 2, y + h / 2], [x - w / 2, y + h / 2]]);

const TW = 0.75; // torso height
const widthAt = (y) => {
  let w = 0.17 + 0.14 * Math.pow(1 - y / TW, 1.3);
  if (y < 0.16) w *= Math.sqrt(Math.max(0, 1 - Math.pow((0.16 - y) / 0.16, 2)));
  return w;
};
const pearG = (y0, y1, grow = 0) => cachedGeo(`pear${y0}_${y1}_${grow}`, () => {
  const L = [], R = [], n = 10;
  for (let i = 0; i <= n; i++) {
    const y = y0 + ((y1 - y0) * i) / n;
    const w = widthAt(clamp(y, 0.001, TW - 0.001)) + grow;
    L.push([-w, y]); R.push([w, y]);
  }
  const pts = [...L, ...R.reverse()];
  const s = new THREE.Shape(); pts.forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y))); s.closePath();
  return new THREE.ShapeGeometry(s);
});
const limbG = (len, w0, w1) => polyG(`limb${len}_${w0}_${w1}`, [[-w0, 0], [w0, 0], [w1, -len], [-w1, -len]]);

const Part = ({ g, c, p = [0, 0, 0], s = [1, 1, 1], r = 0 }) => (
  <mesh geometry={g} material={flat(c)} position={p} scale={s} rotation={[0, 0, r]} />
);

/* ---------- palettes (variants only: palette, hat, glasses) ---------- */
export const VARIANTS = {
  owner: { skin: '#f7e0cf', top: '#d9a93b', bottom: '#7a4e32', pants: '#463a52', hair: '#2b1b1a', hat: 'bowler', hatC: '#3a2f45', glasses: true },
  enemy: { skin: '#f2d8c6', top: '#2f3f6b', bottom: '#4b4f5f', pants: '#2a2a33', hair: '#1c1416', hat: 'top', hatC: '#222029', glasses: false },
  dummy: { skin: '#f3cf45', top: '#f3cf45', bottom: '#2b2b2b', pants: '#2b2b2b', hair: '#f3cf45', hat: 'none', hatC: '#222', glasses: false },
  c1: { skin: '#f4dccb', top: '#c8553d', bottom: '#5b3a4a', pants: '#3a3d55', hair: '#4a2c20', hat: 'cap', hatC: '#2f6f6a', glasses: false },
  c2: { skin: '#efd3be', top: '#3f8f8a', bottom: '#2f5a58', pants: '#52424a', hair: '#1f1a1d', hat: 'none', hatC: '#222', glasses: true },
  c3: { skin: '#f6e2d2', top: '#8d5fa8', bottom: '#5a3a6a', pants: '#3b3b40', hair: '#7a5a2c', hat: 'bowler', hatC: '#5a4a3a', glasses: false },
  c4: { skin: '#f1d6c2', top: '#e0b44c', bottom: '#a8742f', pants: '#34404f', hair: '#2a2024', hat: 'top', hatC: '#4a3a52', glasses: true },
  c5: { skin: '#f5ddcc', top: '#6aa05c', bottom: '#3f6a3c', pants: '#4c3f3f', hair: '#3a2a22', hat: 'cap', hatC: '#c8553d', glasses: false },
};
export const CROWD = ['c1', 'c2', 'c3', 'c4', 'c5'];

function Arm({ side, ang, v, z, hammer }) {
  const sx = side * 0.19;
  return (
    <group position={[sx, 1.2, z]} rotation={[0, 0, ang]}>
      <Part g={limbG(0.62, 0.046, 0.03)} c={INK} p={[0, 0.0, 0]} />
      <Part g={limbG(0.6, 0.03, 0.018)} c={v.top} p={[0, -0.005, 0.004]} />
      {hammer && (
        <group position={[0, -0.64, 0.012]} rotation={[0, 0, hammer.wrist || 0]}>
          <Part g={rectG(0.09, 0.62, 0, -0.3)} c={INK} />
          <Part g={rectG(0.05, 0.6, 0, -0.3)} c="#a9794a" p={[0, 0, 0.004]} />
          <Part g={rectG(0.42, 0.24, 0, -0.66)} c={INK} p={[0, 0, 0.008]} />
          <Part g={rectG(0.36, 0.18, 0, -0.66)} c="#8d929e" p={[0, 0, 0.012]} />
        </group>
      )}
      <Part g={blobG(0.075, 0.075, 3 + side, 0.05, 14)} c={INK} p={[0, -0.64, 0.016]} />
    </group>
  );
}

function Hat({ v, top }) {
  const y = top - 0.04;
  if (v.hat === 'top') return (
    <group position={[0, y, 0.07]}>
      <Part g={blobG(0.33, 0.06, 1, 0.04, 20)} c={INK} p={[0, 0, 0]} />
      <Part g={polyG('topc', [[-0.2, 0], [0.2, 0], [0.18, 0.52], [-0.18, 0.52]])} c={INK} p={[0, 0, 0.002]} s={[1.1, 1.0, 1]} />
      <Part g={blobG(0.29, 0.045, 2, 0.03, 20)} c={v.hatC} p={[0, 0, 0.004]} />
      <Part g={polyG('topc', [[-0.2, 0], [0.2, 0], [0.18, 0.52], [-0.18, 0.52]])} c={v.hatC} p={[0, 0.02, 0.006]} s={[0.92, 0.95, 1]} />
      <Part g={rectG(0.34, 0.07, 0, 0.08)} c="#a8433a" p={[0, 0, 0.01]} />
    </group>
  );
  if (v.hat === 'bowler') return (
    <group position={[0, y, 0.07]}>
      <Part g={blobG(0.36, 0.055, 4, 0.04, 20)} c={INK} />
      <Part g={domeG(0.3, 0.34)} c={INK} p={[0, 0, 0.002]} />
      <Part g={blobG(0.32, 0.04, 5, 0.03, 20)} c={v.hatC} p={[0, 0, 0.004]} />
      <Part g={domeG(0.26, 0.29)} c={v.hatC} p={[0, 0.01, 0.006]} />
      <Part g={rectG(0.5, 0.05, 0, 0.06)} c="#a8433a" p={[0, 0, 0.01]} />
    </group>
  );
  if (v.hat === 'cap') return (
    <group position={[0, y, 0.07]}>
      <Part g={domeG(0.34, 0.26)} c={INK} p={[0, 0, 0.002]} />
      <Part g={blobG(0.22, 0.05, 6, 0.03, 18)} c={INK} p={[0.22, 0.02, 0.001]} />
      <Part g={domeG(0.3, 0.22)} c={v.hatC} p={[0, 0.01, 0.006]} />
      <Part g={blobG(0.19, 0.035, 7, 0.03, 18)} c={v.hatC} p={[0.22, 0.02, 0.004]} />
    </group>
  );
  return null;
}

export function Person({
  position = [0, 0, 0], v: vk = 'owner', scale = 1, seated = false, armL = 0.12, armR = -0.12,
  hammer = null, tilt = 0, squash = [1, 1], phase = 0, bob = 1, headTilt = 0, shadow = true, yawLimit = 0.7,
}) {
  const f = useCurrentFrame(); const { fps } = useVideoConfig(); const t = f / fps;
  const v = typeof vk === 'string' ? VARIANTS[vk] : vk;
  const cam = camAt(t).pos;
  const yaw = clamp(Math.atan2(cam.x - position[0], cam.z - position[2]), -yawLimit, yawLimit);
  const by = bob * 0.018 * Math.sin(2 * Math.PI * 0.9 * t + phase);
  const nod = 0.035 * Math.sin(2 * Math.PI * 0.45 * t + phase) + headTilt;
  const sway = 0.04 * Math.sin(2 * Math.PI * 0.6 * t + phase + 1);
  return (
    <group position={position} rotation={[0, yaw, 0]} scale={[scale * squash[0], scale * squash[1], scale]}>
      {shadow && !seated && (
        <mesh position={[0, 0.012, 0]} rotation={[-Math.PI / 2, 0, 0]} scale={[1, 0.6, 1]}>
          <circleGeometry args={[0.55, 24]} />
          <meshBasicMaterial color="#120a10" transparent opacity={0.28} depthWrite={false} toneMapped={false} />
        </mesh>
      )}
      <group rotation={[0, 0, tilt]}>
        <group position={[0, (seated ? -0.55 : 0) + by, 0]}>
          {!seated && (<>
            <Part g={limbG(0.6, 0.06, 0.042)} c={INK} p={[-0.1, 0.6, 0]} />
            <Part g={limbG(0.58, 0.04, 0.026)} c={v.pants} p={[-0.1, 0.6, 0.004]} />
            <Part g={limbG(0.6, 0.06, 0.042)} c={INK} p={[0.1, 0.6, 0]} />
            <Part g={limbG(0.58, 0.04, 0.026)} c={v.pants} p={[0.1, 0.6, 0.004]} />
            <Part g={blobG(0.11, 0.05, 8, 0.05, 14)} c={INK} p={[-0.12, 0.03, 0.006]} />
            <Part g={blobG(0.11, 0.05, 9, 0.05, 14)} c={INK} p={[0.12, 0.03, 0.006]} />
          </>)}
          {/* torso: ink, two-tone, pocket patch */}
          <Part g={pearG(-0.03, TW + 0.03, 0.03)} c={INK} p={[0, 0.55, 0.012]} />
          <Part g={pearG(0, TW, 0)} c={v.top} p={[0, 0.55, 0.016]} />
          <Part g={pearG(0, 0.26, 0)} c={v.bottom} p={[0, 0.55, 0.02]} />
          <Part g={rectG(0.09, 0.1, 0.1, 0.4)} c={v.bottom} p={[0, 0.55, 0.024]} />
          <Arm side={-1} ang={-armL + sway} v={v} z={0.03} />
          <Arm side={1} ang={armR + 0.0} v={v} z={0.03} hammer={hammer} />
          <Part g={polyG('collar', [[-0.15, 0], [0.15, 0], [0, -0.17]])} c="#fbf6ea" p={[0, 1.31, 0.042]} />
          <Part g={polyG('tie', [[-0.035, 0], [0.035, 0], [0.05, -0.2], [0, -0.25], [-0.05, -0.2]])} c="#a8433a" p={[0, 1.27, 0.046]} />
          {/* head */}
          <group position={[0, 1.62, 0]} rotation={[0, 0, nod]}>
            <Part g={blobG(0.4, 0.38, 11, 0.05, 32)} c={INK} p={[0, 0, 0.05]} />
            <Part g={blobG(0.375, 0.355, 12, 0.025, 32)} c={v.skin} p={[0, 0, 0.054]} />
            {v.hat === 'none' && <Part g={polyG(`fringe${vk}`, [[-0.36, 0.1], [-0.3, 0.26], [0, 0.35], [0.3, 0.26], [0.36, 0.1], [0.3, 0.17], [0.2, 0.08], [0.1, 0.17], [0, 0.07], [-0.1, 0.17], [-0.2, 0.08], [-0.3, 0.17]])} c={v.hair} p={[0, 0, 0.058]} />}
            {v.hat !== 'none' && <Part g={polyG(`fringe2`, [[-0.34, 0.13], [-0.28, 0.24], [0.28, 0.24], [0.34, 0.13], [0.22, 0.2], [0.1, 0.12], [0, 0.2], [-0.1, 0.12], [-0.22, 0.2]])} c={v.hair} p={[0, 0, 0.058]} />}
            {/* calm half-lidded eyes */}
            {[-1, 1].map((s) => (
              <group key={s} position={[s * 0.13, 0.02, 0.062]}>
                <Part g={blobG(0.05, 0.04, 13, 0.02, 14)} c={INK} />
                <Part g={rectG(0.13, 0.04, 0, 0.032)} c={v.skin} p={[0, 0, 0.002]} />
                <Part g={rectG(0.12, 0.012, 0, 0.012)} c={INK} p={[0, 0, 0.004]} />
              </group>
            ))}
            {v.glasses && [-1, 1].map((s) => (
              <Part key={s} g={ringG(0.075, 0.09, 0, Math.PI * 2)} c={INK} p={[s * 0.13, 0.02, 0.07]} />
            ))}
            {v.glasses && <Part g={rectG(0.07, 0.014, 0, 0)} c={INK} p={[0, 0.03, 0.07]} />}
            <Part g={ringG(0.08, 0.092, Math.PI + 0.5, Math.PI - 1.0)} c={INK} p={[0, -0.1, 0.062]} />
            <Hat v={v} top={0.37} />
          </group>
        </group>
      </group>
    </group>
  );
}
