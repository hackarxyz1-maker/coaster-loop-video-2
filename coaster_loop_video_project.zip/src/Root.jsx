import React from 'react';
import { Composition } from 'remotion';
import { Full } from './Full';
import { FPS, DUR } from './plan';

export const Root = () => (
  <Composition id="Full" component={Full} durationInFrames={Math.ceil(DUR * FPS)} fps={FPS} width={720} height={1280} />
);
