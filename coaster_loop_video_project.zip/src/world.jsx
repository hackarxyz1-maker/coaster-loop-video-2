import React from 'react';
import * as THREE from 'three';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import {
  Inked, Sign, toon, flat, painted, signTex, boxG, cylG, sphG, coneG, torG, planeG, wallG, cachedGeo, mergeGeometries, INK,
} from './kit';
import { Person, CROWD } from './char3';
import {
  sstep, seq, clamp, lerp, ownerLoop, RIVAL_LOOP, MINI_LOOP, hammerArm, ownerS, rivalS, ENT, EXT, X_SHOP, X_PARK, PARK,
} from './plan';

const V3 = THREE.Vector3;
const R_LOOP = 2.6, ZO = 1.0, BASE = 0.45;

/* =====================================================================
   Loop track: built from a closed-form loop curve; shape morphs over time
   x = w R sin(th) (1 + s (1+cos th)/2),  y = h R (1 - cos th)
   s > 0 widens (softens) the bottom bend; w < 1 and h > 1 make it tall and thin
   ===================================================================== */
const trackCache = new Map();
export function getTrack(p, ent = ENT, ext = EXT, rr = 0.06) {
  const q = (v) => (Math.round(v / 0.02) * 0.02).toFixed(2);
  const key = `${q(p.w)}_${q(p.h)}_${q(p.s)}_${ent}_${ext}_${rr}`;
  if (trackCache.has(key)) return trackCache.get(key);
  const w = +q(p.w), h = +q(p.h), s = +q(p.s);
  const pts = [];
  for (let x = -ent; x < 0; x += 2) pts.push(new V3(x, BASE, -ZO / 2));
  const n = 72;
  for (let k = 0; k <= n; k++) {
    const th = (k / n) * Math.PI * 2;
    pts.push(new V3(w * R_LOOP * Math.sin(th) * (1 + (s * (1 + Math.cos(th))) / 2), h * R_LOOP * (1 - Math.cos(th)) + BASE, ZO * (th / (Math.PI * 2) - 0.5)));
  }
  for (let x = 2; x <= ext; x += 2) pts.push(new V3(x, BASE, ZO / 2));
  const curve = new THREE.CatmullRomCurve3(pts, false, 'centripetal');
  const L = curve.getLength();
  const M = Math.ceil(L / 0.25);
  const sampled = [];
  for (let i = 0; i <= M; i++) sampled.push(curve.getPointAt(i / M));
  const rails = [-0.28, 0.28].map((dz) => new THREE.TubeGeometry(
    new THREE.CatmullRomCurve3(sampled.map((v) => new V3(v.x, v.y, v.z + dz))), M, rr, 6, false));
  const ties = [];
  for (let d = 0.3; d < L; d += 0.55) {
    const u = d / L, pp = curve.getPointAt(u), tn = curve.getTangentAt(u);
    const k = rr / 0.06;
    const g = new THREE.BoxGeometry(0.14 * k, 0.08 * k, 0.8);
    g.rotateZ(Math.atan2(tn.y, tn.x));
    g.translate(pp.x, pp.y - 0.1 * k, pp.z);
    ties.push(g);
  }
  const tiesGeo = mergeGeometries(ties);
  // supports: entry / exit posts plus two outside the loop sides
  const posts = [];
  [-10, -6, -2].forEach((x) => posts.push([x, BASE - 0.12, -ZO / 2]));
  [2, 6, 10].forEach((x) => { if (x <= ext) posts.push([x, BASE - 0.12, ZO / 2]); });
  [Math.PI / 2, (3 * Math.PI) / 2].forEach((th) => posts.push([
    w * R_LOOP * Math.sin(th) * (1 + (s * (1 + Math.cos(th))) / 2), h * R_LOOP * (1 - Math.cos(th)) + BASE - 0.12, ZO * (th / (Math.PI * 2) - 0.5)]));
  const out = { curve, L, rails, tiesGeo, posts, key };
  trackCache.set(key, out);
  return out;
}
export function trackFrame(track, s) {
  const u = clamp(s / track.L, 0, 1);
  const p = track.curve.getPointAt(u), tn = track.curve.getTangentAt(u);
  return { p, ang: Math.atan2(tn.y, tn.x), nx: -tn.y, ny: tn.x };
}

function Ring({ pos, k, color, r = 1.1 }) {
  if (k <= 0.01) return null;
  return (
    <group position={pos} scale={[k, k, k]}>
      <mesh geometry={torG(r, 0.1, 8, 40)} material={flat(color, { fog: false })} />
      <mesh geometry={torG(r + 0.1, 0.03, 6, 40)} material={flat(INK)} />
      <mesh geometry={torG(r - 0.1, 0.03, 6, 40)} material={flat(INK)} />
    </group>
  );
}

export function LoopTrack({ cx = 0, cz = 0, y = 0, p, ent = ENT, ext = EXT, scale = 1, trolleys = [], rings = [], rr = 0.06 }) {
  const tr = getTrack(p, ent, ext, rr);
  const tieMap = painted('planks', '#9c7a52', 1, 1);
  return (
    <group position={[cx, y, cz]} scale={[scale, scale, scale]}>
      {tr.rails.map((g, i) => <Inked key={i} geo={g} color="#c3c7d1" thick={0.03} edge={false} />)}
      <Inked geo={tr.tiesGeo} color="#9c7a52" map={tieMap} thick={0.02} edge={false} />
      {tr.posts.map(([x, py, z], i) => py > 0.2 && (
        <Inked key={i} geo={cylG(0.1 * rr / 0.06, 0.12 * rr / 0.06, py, 10)} color="#7584ad" thick={0.03} edge={false} position={[x, py / 2, z]} />
      ))}
      {trolleys.map((tz, i) => {
        const f = trackFrame(tr, tz.s);
        return (
          <group key={i} position={[f.p.x, f.p.y, f.p.z]} rotation={[0, 0, f.ang]}>
            <Inked geo={boxG(1.5, 0.36, 0.85)} color={tz.color || '#d1503f'} thick={0.03} position={[0, 0.3, 0]} />
            <Inked geo={boxG(0.3, 0.5, 0.85)} color={tz.color || '#d1503f'} thick={0.03} position={[-0.6, 0.62, 0]} />
            <Inked geo={boxG(0.3, 0.14, 0.7)} color="#e9d9a8" thick={0.025} position={[0.72, 0.52, 0]} />
          </group>
        );
      })}
      {rings.map((rg, i) => {
        const f = trackFrame(tr, rg.s);
        return <Ring key={i} pos={[f.p.x, f.p.y + (rg.dy || 0), f.p.z + 0.5]} k={rg.k} color={rg.color} r={rg.r || 1.1} />;
      })}
    </group>
  );
}

/* rider positions follow trolley frames (world coords). */
export function seatWorld(tr, s, cx, cz, scale = 1, lift = 0.62) {
  const f = trackFrame(tr, s);
  return { pos: [cx + (f.p.x + f.nx * lift) * scale, (f.p.y + f.ny * lift) * scale, cz + (f.p.z + 0.12) * scale], ang: f.ang };
}

/* ======================================================================
   YARD (night test yard) x = 0
   ====================================================================== */
export function Yard() {
  const brick = painted('brick', '#8c5a4a', 0.25, 0.25);
  const dirt = painted('dirt', '#9a8170', 18, 14);
  const crateMap = painted('planks', '#9c7a52', 1, 1);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, -8]} geometry={planeG(100, 70)} material={toon('#9a8170', dirt)} receiveShadow />
      {/* warehouse backdrop with real window reveals */}
      <Inked geo={wallG(36, 8, [{ x: -10, y: 2.8, w: 2.6, h: 2.2 }, { x: -3.5, y: 2.8, w: 2.6, h: 2.2 }, { x: 3.5, y: 2.8, w: 2.6, h: 2.2 }, { x: 10, y: 2.8, w: 2.6, h: 2.2 }], 0.7)}
        color="#8c5a4a" map={brick} thick={0.05} position={[0, 0, -9]} />
      {[-10, -3.5, 3.5, 10].map((x) => (
        <mesh key={x} position={[x, 3.9, -9.3]} geometry={planeG(2.7, 2.3)} material={flat('#f3cf7a')} />
      ))}
      <Inked geo={boxG(37, 0.55, 1.4)} color="#6d4a3d" thick={0.04} position={[0, 8.2, -9]} />
      <Inked geo={boxG(3, 4.2, 1.2)} color="#7a5144" map={brick} thick={0.04} position={[15, 2.1, -8.2]} />
      {/* fence in the foreground (blurred by depth of field) */}
      {[2, 3.2, 4.4, 5.6, 6.8].map((x) => (
        <Inked key={x} geo={boxG(0.16, 1.5, 0.16)} color="#8a6a4a" thick={0.025} position={[x, 0.75, 4.2]} />
      ))}
      <Inked geo={boxG(5.2, 0.12, 0.1)} color="#8a6a4a" thick={0.025} position={[4.4, 1.1, 4.2]} />
      <Inked geo={boxG(5.2, 0.12, 0.1)} color="#8a6a4a" thick={0.025} position={[4.4, 0.6, 4.2]} />
      {/* flood light */}
      <Inked geo={cylG(0.08, 0.12, 6, 8)} color="#5e6272" thick={0.03} position={[-6.2, 3, 2.4]} />
      <Inked geo={boxG(0.9, 0.5, 0.5)} color="#5e6272" thick={0.03} position={[-6.2, 6.1, 2.4]} />
      <mesh position={[-5.7, 6.1, 2.66]} geometry={planeG(0.7, 0.34)} material={flat('#fff0b8', { fog: false })} />
      {/* crates, barrels */}
      <Inked geo={boxG(1.1, 1.1, 1.1)} color="#9c7a52" map={crateMap} thick={0.03} position={[6.5, 0.55, -2.6]} />
      <Inked geo={boxG(0.9, 0.9, 0.9)} color="#9c7a52" map={crateMap} thick={0.03} position={[7.7, 0.45, -2.2]} rotation={[0, 0.4, 0]} />
      <Inked geo={boxG(0.9, 0.9, 0.9)} color="#a58358" map={crateMap} thick={0.03} position={[7.0, 1.5, -2.5]} rotation={[0, 0.2, 0]} />
      <Inked geo={cylG(0.42, 0.42, 1.0, 14)} color="#4f6f8f" thick={0.03} position={[-7.2, 0.5, -1.4]} />
      <Inked geo={cylG(0.42, 0.42, 1.0, 14)} color="#7f4f4f" thick={0.03} position={[-8.1, 0.5, -1.0]} />
      {/* painted signs inside the world */}
      <Sign text="टेस्ट ट्रैक" w={2.4} h={0.9} position={[3.9, 1.7, -3.0]} />
      <Sign text="कल ओपनिंग" w={2.6} h={0.95} position={[-7.0, 2.1, -1.8]} />
      <mesh position={[-24, 22, -52]} geometry={sphG(3.4, 24, 16)} material={flat('#fff3d0', { fog: false })} />
    </group>
  );
}

/* ======================================================================
   WORKSHOP x = 60
   ====================================================================== */
export function Workshop({ t }) {
  const cx = X_SHOP;
  const plank = painted('planks', '#9a7452', 6, 4);
  const plaster = painted('plain', '#d9c2a1', 0.25, 0.25);
  const copyK = sstep(10.6, 11.2, t);
  const bp = signTex('ब्लूप्रिंट', { w: 512, h: 384, bg: '#2f5a8f', fg: '#e3f2ff', size: 70 });
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[cx, 0, 0]} geometry={planeG(16, 10)} material={toon('#9a7452', plank)} receiveShadow />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[cx, -0.01, -22]} geometry={planeG(90, 40)} material={toon('#4b4a55')} receiveShadow />
      <Inked geo={wallG(16, 5.2, [{ x: 3.6, y: 1.0, w: 2.8, h: 2.1 }], 0.5)} color="#d9c2a1" map={plaster} thick={0.045} position={[cx, 0, -4]} />
      <Inked geo={boxG(3.2, 0.14, 0.7)} color="#8a6a4a" thick={0.03} position={[cx + 3.6, 0.98, -3.9]} />
      <Inked geo={boxG(30, 7, 1)} color="#3d3b4d" thick={0.05} position={[cx + 3, 3.5, -13]} />
      <mesh position={[cx + 3.6, 2.05, -7]} geometry={planeG(3, 2.4)} material={flat('#5a4a7a', { fog: false })} />
      {/* blueprint on the wall */}
      <group position={[cx - 3.0, 2.7, -3.72]}>
        <Inked geo={boxG(2.7, 2.1, 0.06)} color="#8a6a4a" thick={0.02} />
        <mesh position={[0, 0, 0.04]} geometry={planeG(2.55, 1.95)} material={flat('#ffffff', { map: bp })} />
        <mesh position={[0, -0.12, 0.05]} geometry={torG(0.55, 0.018, 6, 40)} material={flat('#e3f2ff')} />
      </group>
      {/* desk */}
      <Inked geo={boxG(5.0, 0.14, 1.4)} color="#7b5a3a" thick={0.03} position={[cx, 1.0, -2.3]} />
      {[[-2.3, -2.9], [2.3, -2.9], [-2.3, -1.7], [2.3, -1.7]].map(([x, z], i) => (
        <Inked key={i} geo={boxG(0.14, 0.95, 0.14)} color="#6a4a2f" thick={0.025} position={[cx + x, 0.5, z]} />
      ))}
      {/* two identical models: the real one and the copy */}
      <LoopTrack cx={cx - 1.3} cz={-2.3} y={1.08} p={MINI_LOOP} ent={4} ext={4} scale={0.17} rr={0.2} />
      <group scale={[copyK, copyK, copyK]} position={[cx + 1.3, 1.08, -2.3]}>
        <LoopTrack cx={0} cz={0} y={0} p={MINI_LOOP} ent={4} ext={4} scale={0.17} rr={0.2} />
      </group>
      <Sign text="असली" w={0.9} h={0.34} size={70} position={[cx - 1.3, 1.34, -1.8]} />
      {copyK > 0.5 && <Sign text="नकल" w={0.9} h={0.34} size={70} position={[cx + 1.3, 1.34, -1.8]} />}
      {/* desk lamp */}
      <Inked geo={cylG(0.12, 0.16, 0.06, 12)} color="#4d5a73" thick={0.02} position={[cx - 2.2, 1.1, -2.6]} />
      <Inked geo={cylG(0.03, 0.03, 0.7, 8)} color="#4d5a73" thick={0.02} position={[cx - 2.2, 1.45, -2.6]} />
      <Inked geo={coneG(0.22, 0.26, 12)} color="#d9a93b" thick={0.02} position={[cx - 2.0, 1.85, -2.6]} rotation={[0, 0, -0.8]} />
      {/* foreground chair (blurred) */}
      <Inked geo={boxG(0.8, 0.12, 0.8)} color="#6a4a2f" thick={0.03} position={[cx - 4.0, 0.9, 2.2]} />
      <Inked geo={boxG(0.8, 0.9, 0.1)} color="#6a4a2f" thick={0.03} position={[cx - 4.0, 1.4, 1.8]} />
      {[[-0.35, -0.35], [0.35, -0.35], [-0.35, 0.35], [0.35, 0.35]].map(([x, z], i) => (
        <Inked key={i} geo={boxG(0.08, 0.85, 0.08)} color="#6a4a2f" thick={0.02} position={[cx - 4.0 + x, 0.43, 2.2 + z]} />
      ))}
    </group>
  );
}

/* ======================================================================
   PARK (day) x = 120
   ====================================================================== */
function Ferris({ t }) {
  const rot = t * 0.12;
  return (
    <group position={[X_PARK - 4, 8.2, -17]}>
      <group rotation={[0, 0, rot]}>
        <Inked geo={torG(7.5, 0.15, 8, 48)} color="#d9a93b" thick={0.05} edge={false} />
        <Inked geo={torG(7.5, 0.15, 8, 48)} color="#d9a93b" thick={0.05} edge={false} position={[0, 0, 0.9]} />
        {Array.from({ length: 8 }).map((_, i) => (
          <Inked key={i} geo={boxG(15, 0.1, 0.1)} color="#cfd3dc" thick={0.03} edge={false} rotation={[0, 0, (i * Math.PI) / 8]} position={[0, 0, 0.45]} />
        ))}
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <group key={i} position={[Math.cos(a) * 7.5, Math.sin(a) * 7.5, 0.45]} rotation={[0, 0, -rot]}>
              <Inked geo={boxG(1.0, 0.9, 0.9)} color={['#c8553d', '#3f8f8a', '#8d5fa8', '#e0b44c'][i % 4]} thick={0.04} position={[0, -0.6, 0]} />
            </group>
          );
        })}
      </group>
      <Inked geo={cylG(0.5, 0.5, 1.4, 12)} color="#7584ad" thick={0.04} rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.45]} />
      <Inked geo={boxG(0.4, 9, 0.4)} color="#7584ad" thick={0.04} position={[-3.2, -4.2, 0.45]} rotation={[0, 0, -0.38]} />
      <Inked geo={boxG(0.4, 9, 0.4)} color="#7584ad" thick={0.04} position={[3.2, -4.2, 0.45]} rotation={[0, 0, 0.38]} />
    </group>
  );
}

function Tree({ x, z, s = 1 }) {
  return (
    <group position={[x, 0, z]} scale={[s, s, s]}>
      <Inked geo={cylG(0.2, 0.28, 1.8, 8)} color="#7b5a3a" thick={0.04} position={[0, 0.9, 0]} />
      <Inked geo={sphG(1.3, 14, 10)} color="#5f9a4f" thick={0.06} edge={false} position={[0, 2.8, 0]} />
      <Inked geo={sphG(0.9, 14, 10)} color="#74b05c" thick={0.05} edge={false} position={[0.8, 3.4, 0.2]} />
    </group>
  );
}
function Stall({ x, z, c }) {
  return (
    <group position={[x, 0, z]}>
      <Inked geo={boxG(2.6, 1.8, 1.8)} color="#e9d9a8" thick={0.04} position={[0, 0.9, 0]} />
      <Inked geo={cylG(0.01, 2.2, 1.0, 4)} color={c} thick={0.05} position={[0, 2.3, 0]} rotation={[0, Math.PI / 4, 0]} />
    </group>
  );
}
function LampPost({ x, z }) {
  return (
    <group position={[x, 0, z]}>
      <Inked geo={cylG(0.07, 0.11, 4.6, 8)} color="#4d5a73" thick={0.03} position={[0, 2.3, 0]} />
      <Inked geo={sphG(0.3, 14, 10)} color="#fff0b8" thick={0.03} edge={false} position={[0, 4.8, 0]} />
    </group>
  );
}

export function Park({ t }) {
  const grass = painted('grass', '#7bb05a', 30, 20);
  const path = painted('dirt', '#d6c29a', 12, 1);
  const rivalCx = PARK.rivalCx, ownerCx = PARK.ownerCx;
  const ow = ownerLoop(99);
  const trO = getTrack(ow);
  const trR = getTrack(RIVAL_LOOP);
  const LO = trO.L, LR = trR.L;
  const sO = ownerS(t, LO);
  const midTop = ENT + 0.5 * (LO - ENT - EXT);
  const pulse = (a, b) => sstep(a, a + 0.3, t) * (1 - sstep(b - 0.3, b, t)) * (1 + 0.12 * Math.sin(t * 9));
  const rivalRide = t < 57.6 ? (((t - 29) * 4.6) % (LR - 6)) + 3 : null;
  const rivalS_ = t >= 57.6 ? rivalS(t) : null;
  const signK = sstep(30.3, 30.8, t);
  const pop = sstep(37.1, 37.8, t);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[120, 0, -14]} geometry={planeG(150, 90)} material={toon('#7bb05a', grass)} receiveShadow />
      <Inked geo={boxG(50, 0.08, 3.6)} color="#d6c29a" map={path} thick={0.02} edge={false} cast={false} position={[114, 0.04, 2.1]} />
      {/* hills & ferris wheel: depth behind the action */}
      {[[85, -46, 26, 9], [128, -50, 30, 11], [160, -44, 22, 8]].map(([x, z, rx, ry], i) => (
        <Inked key={i} geo={sphG(1, 24, 14)} color={['#8fbf72', '#6fa35c', '#82b567'][i]} thick={0.04} edge={false} scale={[rx, ry, 14]} position={[x, -2, z]} />
      ))}
      <Ferris t={t} />
      {[[96, -9, 1.2], [108, -12, 1.0], [124, -10, 1.3], [138, -12, 1.1], [146, -7, 1.0], [90, -6, 1.1]].map(([x, z, s], i) => <Tree key={i} x={x} z={z} s={s} />)}
      <Stall x={100} z={-4.2} c="#c8553d" />
      <Stall x={117} z={-5} c="#3f8f8a" />
      <Stall x={143} z={-4} c="#e0b44c" />
      <LampPost x={113} z={4.4} />
      <LampPost x={127} z={4.6} />
      {/* banner on two poles */}
      <Inked geo={cylG(0.1, 0.12, 6.4, 10)} color="#7b5a3a" thick={0.03} position={[112, 3.2, -2.6]} />
      <Inked geo={cylG(0.1, 0.12, 6.4, 10)} color="#7b5a3a" thick={0.03} position={[122, 3.2, -2.6]} />
      <Sign text="ग्रैंड ओपनिंग" w={9} h={1.4} size={120} bg="#f4d06f" position={[117, 5.8, -2.6]} />
      {/* stations */}
      <Inked geo={boxG(4.4, 0.3, 1.5)} color="#b9a07a" thick={0.03} position={[96, 0.15, 1.1]} />
      <Inked geo={boxG(4.4, 0.3, 1.5)} color="#b9a07a" thick={0.03} position={[122, 0.15, 1.1]} />
      <Sign text="उल्टी राइड" w={2.4} h={0.9} position={[119.2, 2.4, 1.6]} />
      <group scale={[signK, signK, signK]} position={[100.5, 0, -1.8]}>
        <Sign text="परफेक्ट लूप" w={2.8} h={1.0} bg="#cfe9d4" position={[0, 3.2, 0]} />
        <Inked geo={cylG(0.06, 0.06, 3.0, 8)} color="#7b5a3a" thick={0.02} position={[-1.1, 1.5, -0.06]} />
        <Inked geo={cylG(0.06, 0.06, 3.0, 8)} color="#7b5a3a" thick={0.02} position={[1.1, 1.5, -0.06]} />
      </group>
      {/* rival's perfect round loop with a queue */}
      <LoopTrack cx={rivalCx} p={RIVAL_LOOP}
        trolleys={[
          ...(rivalRide !== null ? [{ s: rivalRide, color: '#3f8f8a' }] : []),
          ...(rivalS_ !== null ? [{ s: rivalS_, color: '#2f3f6b' }] : []),
        ]} rings={[{ s: ENT, color: '#d9403a', k: pulse(62.0, 63.95), dy: 0.1, r: 0.9 }]} />
      {Array.from({ length: 8 }).map((_, i) => (
        <Person key={i} v={CROWD[i % 5]} position={[93.4 + i * 0.95, 0.08, 1.9 + ((i * 37) % 5) * 0.06]} phase={i * 1.3} armL={0.15} armR={-0.15} />
      ))}
      {rivalRide !== null && (() => {
        const sp = seatWorld(trR, rivalRide, rivalCx, 0);
        return <Person v="c3" position={sp.pos} tilt={sp.ang} seated scale={0.7} armL={2.6} armR={-2.6} />;
      })()}
      {rivalS_ !== null && (() => {
        const sp = seatWorld(trR, rivalS_, rivalCx, 0);
        return <Person v="enemy" position={sp.pos} tilt={sp.ang} seated scale={0.75} armL={2.7} armR={-2.7} bob={0.4} />;
      })()}
      {/* owner's loop: final tall, thin shape */}
      <LoopTrack cx={ownerCx} p={ow}
        trolleys={[{ s: sO, color: '#d1503f' }]}
        rings={[
          { s: ENT + 0.7, color: '#4fb26a', k: pulse(49.3, 52.0), dy: 0.1, r: 1.0 },
          { s: midTop, color: '#f0a33a', k: pulse(52.3, 55.9), dy: 0, r: 1.0 },
        ]} />
      <OwnerPark t={t} tr={trO} sO={sO} LO={LO} cx={ownerCx} />
      {/* diorama: hairpin road vs loop */}
      <Diorama t={t} pop={pop} />
    </group>
  );
}

function OwnerPark({ t, tr, sO, cx }) {
  const stand = [cx - 8.6, 0.3, 1.15];
  const seat0 = seatWorld(tr, 5, cx, 0).pos;
  const seatNow = seatWorld(tr, sO, cx, 0);
  const endStand = [seatNow.pos[0] + 1.5, 0.0, 1.4];
  let pos, seated = false, ang = 0, armL = 0.15, armR = -0.15;
  if (t < 32.4) pos = stand;
  else if (t < 33.2) {
    const k = sstep(32.4, 33.2, t);
    pos = [lerp(stand[0], seat0[0], k), lerp(stand[1], seat0[1], k) + 0.5 * Math.sin(Math.PI * k), lerp(stand[2], seat0[2], k)];
    seated = k > 0.6;
  } else if (t < 57.4) { pos = seatNow.pos; seated = true; ang = seatNow.ang; armL = 0.0; armR = 0.0; }
  else {
    const k = sstep(57.4, 58.3, t);
    pos = [lerp(seatNow.pos[0], endStand[0], k), lerp(seatNow.pos[1], endStand[1], k) + 0.4 * Math.sin(Math.PI * k), lerp(seatNow.pos[2], endStand[2], k)];
    seated = k < 0.4; ang = seatNow.ang * (1 - k);
    const cheer = sstep(58.0, 58.5, t);
    armL = lerp(0.15, 2.7, cheer); armR = lerp(-0.15, -2.7, cheer);
  }
  return <Person v="owner" position={pos} seated={seated} tilt={seated ? ang : 0} scale={seated ? 0.75 : 1} armL={armL} armR={armR} />;
}

function Diorama({ t, pop }) {
  if (pop <= 0.01) return null;
  const hair = cachedGeo('hairpin', () => {
    const c = new THREE.CatmullRomCurve3([
      new V3(-1.5, 0, 0.45), new V3(-0.5, 0, 0.45), new V3(0.15, 0, 0.3), new V3(0.15, 0, -0.3), new V3(-0.5, 0, -0.45), new V3(-1.2, 0, -0.45),
    ], false, 'centripetal');
    const g = new THREE.TubeGeometry(c, 60, 0.12, 6, false);
    g.scale(1, 0.18, 1);
    g.userData.curve = c;
    return g;
  });
  const curve = hair.userData.curve;
  const car = curve.getPointAt(clamp((t - 37.7) / 7.0, 0, 1));
  const mini = getTrack(MINI_LOOP, 6, 6, 0.2);
  const miniS = t > 42.4 ? ((t - 42.4) * 7.5) % (mini.L - 1) : 0.5;
  const ringK = sstep(45.0, 45.3, t) * (1 - sstep(48.7, 49.0, t)) * (1 + 0.12 * Math.sin(t * 9));
  const k1 = sstep(37.9, 38.3, t), k2 = sstep(43.0, 43.4, t);
  return (
    <group position={[123, 0, 3.2]} scale={[pop, pop, pop]}>
      <Inked geo={boxG(3.9, 0.1, 1.5)} color="#b48a5a" thick={0.025} position={[0, 1.0, 0]} />
      {[[-1.8, -0.6], [1.8, -0.6], [-1.8, 0.6], [1.8, 0.6]].map(([x, z], i) => (
        <Inked key={i} geo={boxG(0.1, 0.96, 0.1)} color="#8a6a4a" thick={0.02} position={[x, 0.5, z]} />
      ))}
      <Inked geo={hair} color="#5d6070" thick={0.015} edge={false} position={[-0.5, 1.12, 0]} />
      <Inked geo={boxG(0.28, 0.12, 0.16)} color="#c8553d" thick={0.015} position={[-0.5 + car.x, 1.22, car.z]} />
      <LoopTrack cx={0.2} cz={0} y={1.08} p={MINI_LOOP} ent={6} ext={6} scale={0.16} rr={0.2} trolleys={[{ s: miniS, color: '#d1503f' }]}
        rings={[{ s: 6.3, color: '#d9403a', k: ringK, dy: 0.1, r: 1.5 }]} />
      <group scale={[k1, k1, k1]} position={[-0.8, 1.45, -0.55]}><Sign text="हेयरपिन" w={0.8} h={0.3} size={64} /></group>
      <group scale={[k2, k2, k2]} position={[1.35, 1.45, -0.55]}><Sign text="लूप" w={0.6} h={0.3} size={64} /></group>
    </group>
  );
}

/* =====================================================================
   Dynamic actors (yard + workshop)
   ===================================================================== */
export function Actors({ t, loc }) {
  const out = [];
  if (loc === 'yard') {
    const tYard = Math.min(t, 28.85);
    const ol = ownerLoop(tYard);
    const squashK = sstep(16.1, 16.45, t) * (1 + 0.07 * Math.sin((t - 16.1) * 18) * (1 - sstep(16.45, 17.2, t)));
    out.push(
      <LoopTrack key="loop" cx={0} p={ol} trolleys={t >= 12.9 ? [{ s: 7, color: '#d1503f' }] : []} />,
      <Person key="owner" v="owner" position={[-0.8, 0, 1.0]} hammer={{ wrist: 0.0 }} armR={hammerArm(t)}
        armL={t > 21.1 && t < 23.8 ? 1.6 : 0.2} headTilt={t > 21.4 && t < 24.0 ? 0.2 : 0} />,
      t >= 12.9 && <Person key="dummy" v="dummy" position={[-4.0, 0, 1.2]} squash={[1 + 0.35 * squashK, 1 - 0.62 * squashK]} armL={0.3} armR={-0.3} bob={0.4} />,
    );
    const can = sstep(16.5, 16.8, t);
    if (can > 0.01) out.push(
      <group key="can" position={[-3.0, 0.14, 1.9]} scale={[can * 1.5, can * 0.5, can * 1.5]}>
        <Inked geo={cylG(0.14, 0.14, 0.34, 14)} color="#c8553d" thick={0.02} />
        <Inked geo={cylG(0.145, 0.145, 0.08, 14)} color="#d9dde6" thick={0.02} position={[0, 0.19, 0]} />
      </group>,
    );
    if (t >= 24.3 && t < 28.85) {
      const push = sstep(24.9, 25.5, t);
      out.push(<Person key="enemy" v="enemy" position={[2.7, 0, 1.4]} armL={lerp(0.2, 1.45, push)} armR={-0.25}
        bob={t < 24.9 ? 3 : 1.4} headTilt={t < 24.9 ? 0.08 * Math.sin(t * 24) : 0} phase={1} />);
    }
  } else if (loc === 'shop') {
    out.push(
      <Person key="owner" v="owner" position={[X_SHOP - 3.9, 0, -1.0]} armL={0.25} armR={t > 8.3 && t < 10.6 ? -1.1 : -0.15} />,
      <Person key="enemy" v="enemy" position={[X_SHOP + 3.6, 0, -4.95]} armL={0.3} armR={-0.8} bob={1.3} phase={2} />,
    );
  }
  return <>{out}</>;
}
