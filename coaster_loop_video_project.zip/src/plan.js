import * as THREE from 'three';

export const FPS = 30;
export const DUR = 63.9;

/* ---- sentence timing (from pauses in the voice-over; word-proportional inside each phrase) ---- */
export const SENT = {
  S1: [0.1, 3.48], S2: [3.48, 6.38], S3: [6.62, 8.3], S4: [8.3, 10.65], S5: [10.65, 13.0],
  S6: [13.0, 17.36], S7: [17.36, 21.05], S8: [21.05, 24.08], S9: [24.3, 24.8], S10: [24.8, 27.53],
  S11: [27.53, 28.76], S12: [28.94, 32.39], S13: [32.39, 33.96], S14: [33.96, 35.21], S15: [35.21, 37.09],
  S16: [37.09, 37.72], S17: [37.72, 42.42], S18: [42.42, 44.93], S19: [44.93, 49.0], S20: [49.24, 51.56],
  S21: [51.56, 55.88], S22: [56.16, 58.6], S23: [58.6, 63.9],
};
// one CUTS array: shot starts, taken from real sentence boundaries
export const CUTS = [0, 6.5, 13.0, 28.85, 58.6];

export const sstep = (a, b, t) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, k) => a + (b - a) * k;

/* smooth piecewise value */
export function seq(K, t) {
  if (t <= K[0][0]) return K[0][1];
  for (let i = 0; i < K.length - 1; i++) {
    if (t < K[i + 1][0]) return lerp(K[i][1], K[i + 1][1], sstep(K[i][0], K[i + 1][0], t));
  }
  return K[K.length - 1][1];
}

/* monotone cubic through keys (zero speed at both ends) */
export function pchip(K, t) {
  const n = K.length;
  if (t <= K[0][0]) return K[0][1];
  if (t >= K[n - 1][0]) return K[n - 1][1];
  const h = [], d = [];
  for (let i = 0; i < n - 1; i++) { h[i] = K[i + 1][0] - K[i][0]; d[i] = (K[i + 1][1] - K[i][1]) / h[i]; }
  const m = [0];
  for (let i = 1; i < n - 1; i++) m.push(d[i - 1] * d[i] <= 0 ? 0 : (2 * d[i - 1] * d[i]) / (d[i - 1] + d[i]));
  m.push(0);
  let i = 0; while (t > K[i + 1][0]) i++;
  const x = (t - K[i][0]) / h[i], x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * K[i][1] + (x3 - 2 * x2 + x) * h[i] * m[i] + (-2 * x3 + 3 * x2) * K[i + 1][1] + (x3 - x2) * h[i] * m[i + 1];
}

/* ---- camera time warp (monotone cubic, ease in / ease out) ---- */
function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

/* ---- world offsets ---- */
export const X_SHOP = 60;
export const X_PARK = 120;
export const PARK = { rivalCx: 104, ownerCx: 130 };

/* ---- camera segments: key = [beat time, pos, look] ---- */
const V = (a) => new THREE.Vector3(...a);
const SEGMENTS = [
  { start: 0, loc: 'yard', keys: [
    [0.0, [4.2, 1.8, 8.2], [-0.5, 2.2, 0]],
    [3.5, [1.2, 1.5, 5.0], [-0.7, 1.3, 0.8]],
    [6.45, [-0.5, 1.3, 3.1], [-0.9, 1.2, 1.0]],
  ] },
  { start: 6.5, loc: 'shop', keys: [
    [6.5, [57.2, 1.7, 3.2], [58.2, 1.2, -1.2]],
    [9.7, [59.6, 1.6, 2.8], [60.1, 1.3, -2.0]],
    [13.0, [62.4, 1.7, 2.6], [63.3, 1.7, -3.8]],
  ] },
  { start: 13.0, loc: 'yard', keys: [
    [13.0, [-2.2, 1.2, 4.2], [-4.0, 0.8, 1.2]],
    [15.5, [-3.2, 1.1, 3.6], [-4.2, 0.7, 1.2]],
    [17.4, [-1.8, 1.3, 4.2], [-1.4, 1.1, 1.0]],
    [21.0, [-0.2, 1.3, 3.7], [-0.2, 0.9, 1.0]],
    [24.1, [1.0, 2.4, 6.2], [0.3, 2.2, 0]],
    [26.4, [3.4, 3.6, 7.0], [0.4, 3.3, 0]],
    [28.85, [4.4, 5.2, 7.2], [0.3, 3.6, 0]],
  ] },
  { start: 28.85, loc: 'park', keys: [
    [28.85, [98.5, 1.7, 5.6], [99.5, 1.3, 2.0]],
    [31.3, [101, 2.2, 7.5], [102.5, 2.2, 0]],
    [33.5, [111, 2.4, 8.5], [113, 2.8, 0]],
    [35.2, [122, 2.3, 7.5], [125.5, 2.6, 0.4]],
    [37.1, [121.0, 1.9, 7.8], [123.0, 1.2, 2.5]],
    [38.6, [123.0, 1.8, 6.6], [123.0, 1.2, 3.2]],
    [43.0, [123.0, 1.75, 6.3], [123.0, 1.2, 3.2]],
    [49.0, [123.4, 1.7, 6.2], [123.3, 1.2, 3.2]],
    [50.4, [127.5, 1.8, 6.8], [129, 1.6, 0.8]],
    [52.5, [130, 3.6, 8.5], [130, 3.4, 0]],
    [55.8, [130, 5.6, 8.5], [130, 5.2, 0]],
    [57.5, [135.5, 3.0, 8.0], [137.5, 1.8, 0.6]],
    [58.6, [138.6, 1.5, 4.6], [139.6, 1.0, 0.6]],
  ] },
  { start: 58.6, loc: 'park', keys: [
    [58.6, [97.0, 1.1, 6.5], [95.5, 0.8, 0.2]],
    [61.2, [101.9, 0.95, 5.2], [102.6, 0.7, 0.0]],
    [63.95, [103.2, 0.8, 3.6], [104.0, 0.55, 0.0]],
  ] },
];
SEGMENTS.forEach((s) => {
  s.T = s.keys.map((k) => k[0]);
  s.posC = new THREE.CatmullRomCurve3(s.keys.map((k) => V(k[1])), false, 'centripetal');
  s.lookC = new THREE.CatmullRomCurve3(s.keys.map((k) => V(k[2])), false, 'centripetal');
});

export function segIndex(t) {
  let i = 0; for (let k = 0; k < SEGMENTS.length; k++) if (t >= SEGMENTS[k].start) i = k; return i;
}
export function locAt(t) { return SEGMENTS[segIndex(t)].loc; }
export function camAt(t) {
  const s = SEGMENTS[segIndex(t)];
  const u = warpU(s.T, t);
  const pos = s.posC.getPoint(u), look = s.lookC.getPoint(u);
  return { pos, look, dist: pos.distanceTo(look), loc: s.loc };
}
export function dipAt(t) {
  let m = 0; CUTS.slice(1).forEach((c) => { m = Math.max(m, clamp(1 - Math.abs(t - c) / 0.2, 0, 1)); }); return m;
}

/* ---- loop shapes over time ---- */
export function ownerLoop(t) {
  const hits = [19.5, 20.2, 20.9];
  let s = 0.9 * sstep(19.4, 21.4, t);
  hits.forEach((h) => { if (t > h) s += 0.07 * Math.exp(-(t - h) * 12) * Math.sin((t - h) * 40); });
  const k = sstep(24.9, 27.5, t);
  return { w: 1 - 0.38 * k, h: 1 + 0.35 * k, s: Math.max(0, s) };
}
export const RIVAL_LOOP = { w: 1, h: 1, s: 0 };
export const MINI_LOOP = { w: 1, h: 1, s: 0 };

/* ---- owner hammer arm (angle from "down", positive swings toward +x) ---- */
export function hammerArm(t) {
  return seq([[0, 0.2], [17.3, 0.2], [18.6, 2.2], [19.25, 2.2], [19.5, 0.9], [19.85, 2.2], [20.2, 0.9], [20.55, 2.2], [20.9, 0.9], [21.4, 1.2], [22.2, 0.15]], t);
}

/* ---- trolley distance-along-track (metres) ---- */
export const ENT = 12, EXT = 12;
export const ownerS = (t, L) => pchip([[48.6, 5], [50.2, 11.5], [52.2, ENT + 0.3 * (L - ENT - EXT)], [54.6, ENT + 0.5 * (L - ENT - EXT)], [56.4, ENT + 0.85 * (L - ENT - EXT)], [58.0, L - 3], [59.6, L - 3]], t);
export const rivalS = (t) => pchip([[58.0, 2], [58.6, 2], [63.9, 12]], t);
