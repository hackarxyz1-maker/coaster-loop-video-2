import React, { useMemo } from 'react';
import * as THREE from 'three';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useThree, useFrame } from '@react-three/fiber';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { camAt, dipAt, locAt } from './plan';
import { CREAM } from './kit';
import { Yard, Workshop, Park, Actors } from './world';

const LOOKS = {
  yard: { bg: '#3a3060', near: 22, far: 75, key: '#ffc98a', ki: 3.0, sky: '#a898dc', gnd: '#7a6a7e', hi: 2.4 },
  shop: { bg: '#4a3326', near: 14, far: 45, key: '#ffd7a0', ki: 2.8, sky: '#f6dcb8', gnd: '#b08a6a', hi: 2.5 },
  park: { bg: '#bfe6f2', near: 40, far: 110, key: '#fff1c9', ki: 3.0, sky: '#eaf7ff', gnd: '#9fb58a', hi: 1.4 },
};

function Env({ t }) {
  const { scene } = useThree();
  const key = React.useRef();
  const hemi = React.useRef();
  React.useEffect(() => { if (key.current) scene.add(key.current.target); return () => { if (key.current) scene.remove(key.current.target); }; }, [scene]);
  useFrame(() => {
    const c = camAt(t); const L = LOOKS[c.loc];
    scene.background = new THREE.Color(L.bg);
    scene.fog = new THREE.Fog(L.bg, L.near, L.far);
    const k = key.current, h = hemi.current;
    k.color.set(L.key); k.intensity = L.ki;
    k.position.set(c.look.x - 9, c.look.y + 15, c.look.z + 9);
    k.target.position.copy(c.look); k.target.updateMatrixWorld();
    h.color.set(L.sky); h.groundColor.set(L.gnd); h.intensity = L.hi;
  }, -9);
  return (
    <>
      <hemisphereLight ref={hemi} />
      <directionalLight ref={key} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-14} shadow-camera-right={14}
        shadow-camera-top={14} shadow-camera-bottom={-14} shadow-camera-near={1} shadow-camera-far={60} shadow-bias={-0.0006} shadow-normalBias={0.03} />
    </>
  );
}

function Rig({ t }) {
  useFrame(({ camera }) => {
    const c = camAt(t);
    camera.fov = 80; camera.near = 0.1; camera.far = 140;
    camera.position.copy(c.pos); camera.lookAt(c.look);
    camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  }, -10);
  return null;
}

function Post({ t }) {
  const { gl, scene, camera, size } = useThree();
  const pack = useMemo(() => {
    const rt = new THREE.WebGLRenderTarget(size.width, size.height, { type: THREE.HalfFloatType, samples: 4 });
    const c = new EffectComposer(gl, rt);
    c.setPixelRatio(1); c.setSize(size.width, size.height);
    c.addPass(new RenderPass(scene, camera));
    const bk = new BokehPass(scene, camera, { focus: 5, aperture: 0.006, maxblur: 0.012 });
    c.addPass(bk);
    c.addPass(new OutputPass());
    return { c, bk };
  }, [gl, scene, camera, size.width, size.height]);
  useFrame(() => {
    pack.bk.uniforms.focus.value = camAt(t).dist;
    pack.c.render();
  }, 1);
  return null;
}

export const Full = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const loc = locAt(t);
  const dip = dipAt(t);
  return (
    <AbsoluteFill style={{ background: CREAM }}>
      <ThreeCanvas width={width} height={height} shadows camera={{ fov: 80, near: 0.1, far: 140, position: [0, 2, 8] }} gl={{ antialias: false }}>
        <Env t={t} />
        <Rig t={t} />
        <Yard />
        <Workshop t={t} />
        <Park t={t} />
        <Actors t={t} loc={loc} />
        <Post t={t} />
      </ThreeCanvas>
      <AbsoluteFill style={{ background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(30,15,20,0.32) 100%)', pointerEvents: 'none' }} />
      <AbsoluteFill style={{ background: CREAM, opacity: dip, pointerEvents: 'none' }} />
    </AbsoluteFill>
  );
};
