import React, { useMemo } from 'react';
import * as THREE from 'three';
import { mergeVertices, mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const INK = '#351f22';
export const CREAM = '#f5ead2';
export const FONT = "'Noto Sans Devanagari','Nirmala UI','Mangal','Kohinoor Devanagari','Lohit Devanagari',sans-serif";

export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------- toon material: 3-band gradient ---------- */
let _grad;
export function gradient() {
  if (!_grad) {
    const d = new Uint8Array([80, 160, 255]);
    _grad = new THREE.DataTexture(d, 3, 1, THREE.RedFormat);
    _grad.minFilter = _grad.magFilter = THREE.NearestFilter;
    _grad.generateMipmaps = false;
    _grad.needsUpdate = true;
  }
  return _grad;
}
const matCache = new Map();
export function toon(color, map) {
  const key = color + (map ? map.uuid : '');
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshToonMaterial({ color, map: map || null, gradientMap: gradient() }));
  }
  return matCache.get(key);
}
const flatCache = new Map();
export function flat(color, opts = {}) {
  const key = color + '|' + (opts.map ? opts.map.uuid : '') + '|' + (opts.transparent ? 't' : '') + (opts.opacity ?? '') + (opts.fog === false ? 'nf' : '');
  if (!flatCache.has(key)) {
    flatCache.set(key, new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide, toneMapped: false, ...opts }));
  }
  return flatCache.get(key);
}

/* ---------- painted flat-colour textures with wear ---------- */
const texCache = new Map();
export function painted(kind, base, rx = 1, ry = 1) {
  const key = `${kind}|${base}|${rx}|${ry}`;
  if (texCache.has(key)) return texCache.get(key);
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  const r = rng(kind.length * 131 + base.charCodeAt(1) * 7 + Math.floor(rx * 3));
  x.fillStyle = base; x.fillRect(0, 0, S, S);
  if (kind === 'planks') {
    for (let i = 0; i < 8; i++) {
      x.fillStyle = `rgba(0,0,0,${0.04 + r() * 0.08})`; x.fillRect(0, i * 32, S, 32);
      x.fillStyle = 'rgba(30,15,10,.5)'; x.fillRect(0, i * 32, S, 2);
      const o = r() * S; x.fillRect(o, i * 32, 2, 32);
    }
  } else if (kind === 'brick') {
    for (let j = 0; j < 8; j++) for (let i = 0; i < 4; i++) {
      const ox = (j % 2) * 32 + i * 64;
      x.fillStyle = `rgba(${r() > .5 ? '255,220,190' : '40,10,5'},${0.05 + r() * 0.1})`;
      x.fillRect(ox % S, j * 32, 62, 30);
    }
    x.fillStyle = 'rgba(40,20,15,.45)';
    for (let j = 0; j <= 8; j++) x.fillRect(0, j * 32, S, 2);
    for (let j = 0; j < 8; j++) for (let i = 0; i < 4; i++) x.fillRect(((j % 2) * 32 + i * 64) % S, j * 32, 2, 32);
  } else if (kind === 'grass') {
    for (let i = 0; i < 260; i++) {
      x.fillStyle = `rgba(${r() > .5 ? '20,70,20' : '230,255,170'},${0.08 + r() * 0.1})`;
      x.fillRect(r() * S, r() * S, 2 + r() * 3, 6 + r() * 8);
    }
  } else if (kind === 'dirt') {
    for (let i = 0; i < 140; i++) {
      x.fillStyle = `rgba(${r() > .5 ? '30,15,10' : '230,200,170'},${0.06 + r() * 0.08})`;
      x.beginPath(); x.ellipse(r() * S, r() * S, 3 + r() * 9, 2 + r() * 5, r() * 3, 0, 7); x.fill();
    }
  }
  // wear: stains, chips, scratches
  for (let i = 0; i < 7; i++) {
    x.fillStyle = `rgba(20,10,5,${0.05 + r() * 0.07})`;
    x.beginPath(); x.ellipse(r() * S, r() * S, 12 + r() * 30, 6 + r() * 16, r() * 3, 0, 7); x.fill();
  }
  for (let i = 0; i < 14; i++) {
    x.fillStyle = 'rgba(255,245,225,.16)'; x.fillRect(r() * S, r() * S, 2 + r() * 6, 2 + r() * 4);
  }
  x.strokeStyle = 'rgba(30,15,10,.2)'; x.lineWidth = 1;
  for (let i = 0; i < 9; i++) { x.beginPath(); const a = r() * S, b = r() * S; x.moveTo(a, b); x.lineTo(a + r() * 40 - 20, b + r() * 40 - 20); x.stroke(); }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  texCache.set(key, t);
  return t;
}

/* ---------- painted sign texture (labels live inside the world) ---------- */
export function signTex(text, { w = 512, h = 192, bg = '#f2e3c0', fg = INK, size = 92, border = true } = {}) {
  const key = `sign|${text}|${w}|${h}|${bg}|${fg}|${size}`;
  if (texCache.has(key)) return texCache.get(key);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h);
  const r = rng(text.length * 17);
  for (let i = 0; i < 10; i++) { x.fillStyle = `rgba(40,20,10,${0.04 + r() * 0.06})`; x.beginPath(); x.ellipse(r() * w, r() * h, 20 + r() * 50, 8 + r() * 20, r() * 3, 0, 7); x.fill(); }
  if (border) { x.strokeStyle = fg; x.lineWidth = 8; x.strokeRect(10, 10, w - 20, h - 20); }
  x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.font = `bold ${size}px ${FONT}`;
  x.fillText(text, w / 2, h / 2 + 4, w - 50);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  texCache.set(key, t);
  return t;
}

/* ---------- cached geometry ---------- */
const GC = new Map();
export const cachedGeo = (k, f) => { if (!GC.has(k)) GC.set(k, f()); return GC.get(k); };
export const boxG = (w, h, d) => cachedGeo(`b${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d));
export const cylG = (rt, rb, h, s = 16) => cachedGeo(`c${rt}_${rb}_${h}_${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
export const sphG = (r, ws = 20, hs = 14) => cachedGeo(`s${r}_${ws}_${hs}`, () => new THREE.SphereGeometry(r, ws, hs));
export const coneG = (r, h, s = 16) => cachedGeo(`k${r}_${h}_${s}`, () => new THREE.ConeGeometry(r, h, s));
export const torG = (R, r, rs = 10, ts = 40) => cachedGeo(`t${R}_${r}_${rs}_${ts}`, () => new THREE.TorusGeometry(R, r, rs, ts));
export const planeG = (w, h) => cachedGeo(`p${w}_${h}`, () => new THREE.PlaneGeometry(w, h));

/* extruded wall with window reveals (real depth, not a cardboard card) */
export function wallG(w, h, openings = [], depth = 0.4) {
  const key = `wall${w}_${h}_${depth}_${JSON.stringify(openings)}`;
  return cachedGeo(key, () => {
    const s = new THREE.Shape();
    s.moveTo(-w / 2, 0); s.lineTo(w / 2, 0); s.lineTo(w / 2, h); s.lineTo(-w / 2, h); s.closePath();
    openings.forEach(({ x, y, w: ow, h: oh }) => {
      const p = new THREE.Path();
      p.moveTo(x - ow / 2, y); p.lineTo(x - ow / 2, y + oh); p.lineTo(x + ow / 2, y + oh); p.lineTo(x + ow / 2, y); p.closePath();
      s.holes.push(p);
    });
    const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false });
    g.translate(0, 0, -depth / 2);
    return g;
  });
}

/* ---------- inked mesh: toon fill + inverted-hull outline + edge lines ---------- */
const hullCache = new WeakMap();
function hullGeo(geo) {
  if (!hullCache.has(geo)) {
    let g = geo.clone();
    ['normal', 'uv', 'uv1', 'color'].forEach((a) => { if (g.attributes[a]) g.deleteAttribute(a); });
    g.clearGroups();
    g = mergeVertices(g, 1e-3);
    g.computeVertexNormals();
    hullCache.set(geo, g);
  }
  return hullCache.get(geo);
}
const hullMats = new Map();
function hullMat(t) {
  if (!hullMats.has(t)) {
    hullMats.set(t, new THREE.ShaderMaterial({
      uniforms: { t: { value: t }, c: { value: new THREE.Color(INK) } },
      vertexShader: 'uniform float t; void main(){ gl_Position = projectionMatrix * modelViewMatrix * vec4(position + normal * t, 1.0); }',
      fragmentShader: 'uniform vec3 c; void main(){ gl_FragColor = vec4(c, 1.0); }',
      side: THREE.BackSide,
    }));
  }
  return hullMats.get(t);
}
const edgeMat = new THREE.LineBasicMaterial({ color: INK });
const edgeCache = new WeakMap();
function edgeGeo(geo) {
  if (!edgeCache.has(geo)) edgeCache.set(geo, new THREE.EdgesGeometry(geo, 32));
  return edgeCache.get(geo);
}

export function Inked({ geo, color = '#ffffff', map, thick = 0.035, edge = true, cast = true, receive = true, children, ...props }) {
  const mat = toon(color, map);
  return (
    <group {...props}>
      <mesh geometry={geo} material={mat} castShadow={cast} receiveShadow={receive} />
      <mesh geometry={hullGeo(geo)} material={hullMat(thick)} />
      {edge && <lineSegments geometry={edgeGeo(geo)} material={edgeMat} />}
      {children}
    </group>
  );
}

/* a painted board in the world (sign with real thickness) */
export function Sign({ text, w = 2.4, h = 0.9, size = 92, bg, fg, ...props }) {
  const cw = w > 5 ? 1536 : 512;
  const ch = Math.round((cw * h) / w);
  const fs = Math.min((size * cw) / 512, ch * 0.6);
  const map = useMemo(() => signTex(text, { w: cw, h: ch, size: fs, bg, fg }), [text, cw, ch, fs, bg, fg]);
  return (
    <group {...props}>
      <Inked geo={boxG(w + 0.1, h + 0.1, 0.1)} color="#8a6a4a" thick={0.025} />
      <mesh position={[0, 0, 0.056]} geometry={planeG(w, h)} material={flat('#ffffff', { map })} />
    </group>
  );
}

export { mergeGeometries };
